//import DataTable from "datatables.net-bs5"
//import DataTable from "DataTables"
//import DataTable from "DataTables"
//import DataTable from "datatables"
//window.DataTable = DataTable();
//window.DataTable = DataTables;
