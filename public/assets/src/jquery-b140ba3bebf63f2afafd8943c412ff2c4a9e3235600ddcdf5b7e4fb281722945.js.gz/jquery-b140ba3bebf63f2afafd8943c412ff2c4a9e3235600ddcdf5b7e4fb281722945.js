import jquery from "jquery"
//import jquery from "https://code.jquery.com/jquery-3.6.0.js"
//import jquery from "ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"
window.jQuery = jquery
window.$ = jquery;
