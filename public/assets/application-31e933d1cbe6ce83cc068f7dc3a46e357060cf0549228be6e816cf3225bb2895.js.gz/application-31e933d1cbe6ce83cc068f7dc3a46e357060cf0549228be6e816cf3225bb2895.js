// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"


//testing

import "./src/jquery"

import "./custom/scripts"
//import "./src/datatables";
